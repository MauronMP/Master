package prueba;

public class Mensaje {

}
