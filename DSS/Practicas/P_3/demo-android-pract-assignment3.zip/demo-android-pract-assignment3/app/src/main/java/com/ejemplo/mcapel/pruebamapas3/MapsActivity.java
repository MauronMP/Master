package com.ejemplo.mcapel.pruebamapas3;

import android.content.Context;
import android.location.LocationManager;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.location.Location;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    double latitude = 0;
    double longitude = 0;
    Location location;
    private GPSTracker gps;
    private LocationManager locManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        gps = new GPSTracker(((Context) this));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtener el fragmento: SupportMapFragment y ser notificado cuando el mapa esté listo para ser utilizado.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipula el mapa una vez que esté disponible.
     * Este callback es activado cuando el mapa esté listo para ser utilizado.
     * Aquí es donde podemos añadir marcadores o líneas, añadir escuchadores(listeners) o mover la cámera.
     * En el caso del ejemplo que se muestra, sólo añadirmos 1 marcador que corresponde con la
     * geolocalización que hace el servicio de GPS o la red (ver detalles en la clase GPSTracker)
     * del lugar donde nos encontramos actualmente.
     * Si los servicios de Google Play no estuvieran instalados en el dispositivo, se le pedirá al usuario que los instale
     * dentro del SupportMapFragment. Este método sólo será activado una vez que el usuario haya
     * instalado los servicios de Google Play y retornado al app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        //La cadena LOCATION_SERVICE se utiliza con la llamada al metodo getSystemService(Class) para encontrar un LocationManager que sirva para controlar actualizaciones de ubicacion
        locManager = (LocationManager) MapsActivity.this.getSystemService(Context.LOCATION_SERVICE);
        location= gps.getLocation();
        latitude= location.getLatitude();
        longitude= location.getLongitude();
        LatLng actual = new LatLng(latitude,longitude);
        Marker miposicion= mMap.addMarker(new MarkerOptions().position(actual).snippet("Seleccione su farmacia mas cercana.").title("Marcador de mi lugar"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(actual));

        miposicion.showInfoWindow();
       CameraPosition campos = new CameraPosition.Builder()
                .target(actual)
                .zoom(16)
                .bearing(45)
                .build();
        CameraUpdate camUp13 = CameraUpdateFactory.newCameraPosition(campos);
       mMap.animateCamera(camUp13);
    }
}
